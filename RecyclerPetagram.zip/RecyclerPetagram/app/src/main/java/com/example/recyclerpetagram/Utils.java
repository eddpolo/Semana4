package com.example.recyclerpetagram;

public class Utils {
    public static final String EMAIL    = "edrodrigo21@gmail.com";
    public static final String PASSWORD =":Edwin21";
}
